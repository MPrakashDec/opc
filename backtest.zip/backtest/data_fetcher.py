"""Fetch historical options data from Dhan API for backtesting."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import pandas as pd
import pytz
import requests

IST = pytz.timezone("Asia/Kolkata")

# Dhan API
ROLLING_OPTION_URL = "https://api.dhan.co/v2/charts/rollingoption"

# Underlying security IDs (from Dhan instrument list)
NIFTY_UNDERLYING_ID = "13"
SENSEX_UNDERLYING_ID = "23"  # BSE Sensex - verify from instrument list

# Lot sizes
NIFTY_LOT = 65
SENSEX_LOT = 20  # Sensex lot size - verify


def fetch_rolling_options(
    access_token: str,
    index: str,
    expiry_code: int,
    strike: str,
    option_type: str,
    from_date: str,
    to_date: str,
    interval: str = "1",
    expiry_flag: str = "WEEK",
) -> pd.DataFrame:
    """Fetch expired options OHLC from Dhan rolling option API.
    
    Args:
        access_token: Dhan API token
        index: 'nifty' or 'sensex'
        expiry_code: 0=current, 1=next, 2=far
        strike: ATM, ATM+1, ATM+2, ... ATM+10, ATM-1, etc.
        option_type: CALL or PUT
        from_date: YYYY-MM-DD
        to_date: YYYY-MM-DD (non-inclusive)
        interval: 1, 5, 15, 25, 60 minutes
        expiry_flag: WEEK or MONTH
    """
    seg = "NSE_FNO" if index.lower() == "nifty" else "BSE_FNO"
    sec_id = NIFTY_UNDERLYING_ID if index.lower() == "nifty" else SENSEX_UNDERLYING_ID
    
    payload = {
        "exchangeSegment": seg,
        "interval": int(interval),
        "securityId": int(sec_id),
        "instrument": "OPTIDX",
        "expiryFlag": expiry_flag,
        # WEEK: expiryCode 0 fails on Dhan API; use 1=current, 2=next
        "expiryCode": int(expiry_code) + (1 if expiry_flag == "WEEK" else 0),
        "strike": strike,
        "drvOptionType": option_type.upper(),
        "requiredData": ["open", "high", "low", "close", "volume", "spot", "strike"],
        "fromDate": from_date,
        "toDate": to_date,
    }

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "access-token": access_token,
    }
    resp = requests.post(ROLLING_OPTION_URL, json=payload, headers=headers, timeout=60)
    # Some builds reject "strike" in requiredData; retry without it (spot-based fallback in backtest).
    if not resp.ok and resp.status_code == 400 and "strike" in payload.get("requiredData", []):
        payload = {**payload, "requiredData": ["open", "high", "low", "close", "volume", "spot"]}
        resp = requests.post(ROLLING_OPTION_URL, json=payload, headers=headers, timeout=60)
    if not resp.ok:
        try:
            err_body = resp.json()
            msg = (
                err_body.get("errorMessage")
                or err_body.get("message")
                or err_body.get("errorCode")
                or str(err_body)
            )
        except ValueError:
            msg = resp.text[:500]
        raise RuntimeError(f"Dhan API {resp.status_code}: {msg}") from None
    data = resp.json()

    # Parse response - structure: data.ce or data.pe
    opt_key = "ce" if option_type.upper() == "CALL" else "pe"
    series = data.get("data", {}).get(opt_key)
    if not series:
        return pd.DataFrame()
    
    ts = series.get("timestamp", [])
    if not ts:
        return pd.DataFrame()

    n = len(ts)
    def to_list(arr, default=0):
        a = list(arr or [])
        if len(a) < n:
            a = a + [a[-1] if a else default] * (n - len(a))
        return a[:n]

    df = pd.DataFrame({
        "open": to_list(series.get("open")),
        "high": to_list(series.get("high")),
        "low": to_list(series.get("low")),
        "close": to_list(series.get("close")),
        "volume": to_list(series.get("volume"), 0),
        "spot": to_list(series.get("spot")),
        "strike": to_list(series.get("strike")),
    })
    # Convert epoch to IST (like newDhan1_with_fut.py)
    dt_index = pd.to_datetime(ts, unit="s", utc=True).tz_convert(IST)
    df["timestamp"] = dt_index
    df = df.set_index("timestamp")
    return df


def _row_at_or_before(df: pd.DataFrame, dt: datetime) -> pd.Series | None:
    """Last row at or before dt (IST)."""
    if df.empty:
        return None
    if dt.tzinfo is None:
        dt = IST.localize(dt)
    ts = pd.Timestamp(dt)
    if df.index.tz is not None:
        ts = ts.tz_localize(IST) if ts.tz is None else ts.tz_convert(IST)
    mask = df.index <= ts
    if not mask.any():
        return None
    return df.loc[mask].iloc[-1]


def get_price_at_time(df: pd.DataFrame, dt: datetime) -> float | None:
    """Get close price at or just before given datetime (dt assumed IST if naive)."""
    row = _row_at_or_before(df, dt)
    if row is None:
        return None
    return float(row["close"])


def get_spot_at_time(df: pd.DataFrame, dt: datetime) -> float | None:
    """Underlying spot/index at or just before dt."""
    row = _row_at_or_before(df, dt)
    if row is None or "spot" not in row.index:
        return None
    v = row["spot"]
    if pd.isna(v) or float(v) <= 0:
        return None
    return float(v)


def get_strike_at_time(df: pd.DataFrame, dt: datetime) -> float | None:
    """Option strike from API series at or just before dt."""
    row = _row_at_or_before(df, dt)
    if row is None or "strike" not in row.index:
        return None
    v = row["strike"]
    if pd.isna(v) or float(v) <= 0:
        return None
    return float(v)


def find_profit_target_exit(
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    df3: pd.DataFrame,
    entry_dt: pd.Timestamp,
    p1: float,
    p2: float,
    p3: float,
    lot_size: int,
    profit_pct: float = 0.025,
    max_dt: pd.Timestamp | None = None,
) -> pd.Timestamp | None:
    """Find first timestamp when total PnL reaches profit_pct of capital.
    Capital = premium paid for buys (3*lot*p1 + 6*lot*p2).
    Returns None if target never reached.
    """
    capital = (3 * lot_size * p1) + (6 * lot_size * p2)
    if capital <= 0:
        return None
    if df1.empty or df2.empty or df3.empty:
        return None

    # Ensure timezone-aware for comparison (assumed IST if naive)
    if entry_dt.tzinfo is None:
        entry_dt = pd.Timestamp(entry_dt).tz_localize(IST)
    if max_dt is not None and max_dt.tzinfo is None:
        max_dt = pd.Timestamp(max_dt).tz_localize(IST)

    # Reindex to union of timestamps, forward-fill
    all_idx = df1.index.union(df2.index).union(df3.index)
    all_idx = all_idx[all_idx >= entry_dt]
    if max_dt is not None:
        all_idx = all_idx[all_idx <= max_dt]
    all_idx = sorted(all_idx.unique())

    s1 = df1["close"].reindex(all_idx).ffill()
    s2 = df2["close"].reindex(all_idx).ffill()
    s3 = df3["close"].reindex(all_idx).ffill()

    for ts in all_idx:
        c1, c2, c3 = s1.get(ts), s2.get(ts), s3.get(ts)
        if pd.isna(c1) or pd.isna(c2) or pd.isna(c3):
            continue
        pnl = (float(c1) - p1) * 3 * lot_size + (float(c2) - p2) * 6 * lot_size + (p3 - float(c3)) * 9 * lot_size
        if pnl / capital >= profit_pct:
            return ts
    return None
